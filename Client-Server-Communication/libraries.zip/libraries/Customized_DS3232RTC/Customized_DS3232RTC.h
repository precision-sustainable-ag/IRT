// Customized_DS3232RTC.h

#ifndef Customized_DS3232RTC_H
#define Customized_DS3232RTC_H

#include <Arduino.h>

// DS3232 I2C Address
#define RTC_ADDR 0x68

// DS3232 Register Addresses
#define RTC_SECONDS 0x00
#define RTC_MINUTES 0x01
#define RTC_HOURS 0x02
#define RTC_DAY 0x03
#define RTC_DATE 0x04
#define RTC_MONTH 0x05
#define RTC_YEAR 0x06
#define ALM1_SECONDS 0x07
#define ALM1_MINUTES 0x08
#define ALM1_HOURS 0x09
#define ALM1_DAYDATE 0x0A
#define ALM2_MINUTES 0x0B
#define ALM2_HOURS 0x0C
#define ALM2_DAYDATE 0x0D
#define RTC_CONTROL 0x0E
#define RTC_STATUS 0x0F
#define RTC_AGING 0x10
#define RTC_TEMP_MSB 0x11
#define RTC_TEMP_LSB 0x12
#define SRAM_START_ADDR 0x14    // first SRAM address
#define SRAM_SIZE 236           // number of bytes of SRAM

// Constants for alarm functions
#define ALARM_1 1
#define ALARM_2 2

// Alarm mask bits
#define A1M1 7
#define A1M2 7
#define A1M3 7
#define A1M4 7
#define DYDT 6  // Day/Date flag bit in alarm Day/Date registers

// Status register bits
#define OSF 7
#define BB32KHZ 6
#define CRATE1 5
#define CRATE0 4
#define EN32KHZ 3
#define BSY 2
#define A2F 1
#define A1F 0

// Control register bits
#define A1IE 0

// Other masks
#define DS1307_CH 7                // for DS1307 compatibility, Clock Halt bit in Seconds register
#define HR1224 6                   // Hours register 12 or 24 hour mode (24 hour mode==0)
#define CENTURY 7                  // Century bit in Month register

// Convert between 2000 year and time structure year (1970)
#define y2kYearToTm(Y) ((Y) + 30)
#define tmYearToY2k(Y) ((Y) - 30)

// tmElements_t structure
typedef struct {
  uint8_t Second;
  uint8_t Minute;
  uint8_t Hour;
  uint8_t Wday;   // day of week, sunday is day 1
  uint8_t Day;
  uint8_t Month;
  uint8_t Year;   // offset from 1970;
} tmElements_t;

class Customized_DS3232RTC {
public:
  Customized_DS3232RTC();
  void begin();
  void read(tmElements_t &tm);
  void write(tmElements_t &tm);
  void writeRTC(byte addr, byte values);
  byte readRTC(byte addr);
  void setAlarm(byte minutes);
  void setAlarm(uint8_t alarmType, byte seconds, byte minutes, byte hours, byte daydate);
  void alarmInterrupt(byte alarmNumber, bool interruptEnabled);
  bool alarm(byte alarmNumber);
private:
  uint8_t dec2bcd(uint8_t n);
  uint8_t bcd2dec(uint8_t n);
};

#ifdef ARDUINO_ARCH_AVR
extern Customized_DS3232RTC RTC;
#endif

#ifndef _BV
#define _BV(bit) (1 << (bit))
#endif

#endif
