// Customized_DS3232RTC.cpp

#include <Customized_DS3232RTC.h>
#include <Wire.h>

// Constructor.
Customized_DS3232RTC::Customized_DS3232RTC() {
  Wire.begin();
}

// Initialize the I2C bus.
void Customized_DS3232RTC::begin() {
  Wire.begin();
}

// Read the current time from the RTC and return it in a tmElements_t structure.
void Customized_DS3232RTC::read(tmElements_t &tm) {
    Wire.beginTransmission(RTC_ADDR);
    Wire.write(RTC_SECONDS);
    Wire.endTransmission();
    Wire.requestFrom(RTC_ADDR, 8);
    tm.Second = bcd2dec(Wire.read() & ~_BV(DS1307_CH));
    tm.Minute = bcd2dec(Wire.read());
    tm.Hour = bcd2dec(Wire.read() & ~_BV(HR1224));    // assumes 24hr clock
    tm.Wday = Wire.read();
    tm.Day = bcd2dec(Wire.read());
    tm.Month = bcd2dec(Wire.read() & ~_BV(CENTURY));  // don't use the Century bit
    tm.Year = bcd2dec(Wire.read());
    tm.Year = y2kYearToTm(bcd2dec(Wire.read()));
}

// Set the RTC time from a tmElements_t structure and clear the
// oscillator stop flag (OSF) in the Control/Status register.
// Returns the I2C status (zero if successful).
void Customized_DS3232RTC::write(tmElements_t &tm) {
    Wire.beginTransmission(RTC_ADDR);
    Wire.write((uint8_t)RTC_SECONDS);
    Wire.write(dec2bcd(tm.Second));
    Wire.write(dec2bcd(tm.Minute));
    Wire.write(dec2bcd(tm.Hour));         // sets 24 hour format (Bit 6 == 0)
    Wire.write(tm.Wday);
    Wire.write(dec2bcd(tm.Day));
    Wire.write(dec2bcd(tm.Month));
    Wire.write(dec2bcd(tmYearToY2k(tm.Year)));
    Wire.endTransmission();
    uint8_t s = readRTC(RTC_STATUS);        // read the status register
    writeRTC( RTC_STATUS, s & ~_BV(OSF) );  // clear the Oscillator Stop Flag
}

// write one byte to RTC at addr
void Customized_DS3232RTC::writeRTC(byte addr, byte values) {
    Wire.beginTransmission(RTC_ADDR);
    Wire.write(addr);
    Wire.write(values);
    Wire.endTransmission();
}

// read one byte from RTC at addr
byte Customized_DS3232RTC::readRTC(byte addr) {
    Wire.beginTransmission(RTC_ADDR);
    Wire.write(addr);
    Wire.endTransmission();
    Wire.requestFrom(RTC_ADDR, 1);
    byte value = Wire.read();
    return value;
}

// Set the alarm matching minutes
void Customized_DS3232RTC::setAlarm(byte minutes) {
  uint8_t alarmType = 0x0C; // match minutes and seconds
  setAlarm(alarmType, 0, minutes, 0, 0);
}

// Set alarm with alarmType and alarm time
void Customized_DS3232RTC::setAlarm(uint8_t alarmType, byte seconds, byte minutes, byte hours, byte daydate) {
    uint8_t addr;

    seconds = dec2bcd(seconds);
    minutes = dec2bcd(minutes);
    hours = dec2bcd(hours);
    daydate = dec2bcd(daydate);
    if (alarmType & 0x01) seconds |= _BV(A1M1);
    if (alarmType & 0x02) minutes |= _BV(A1M2);
    if (alarmType & 0x04) hours |= _BV(A1M3);
    if (alarmType & 0x10) daydate |= _BV(DYDT);
    if (alarmType & 0x08) daydate |= _BV(A1M4);

    addr = ALM1_SECONDS;
    writeRTC(addr++, seconds);
    writeRTC(addr++, minutes);
    writeRTC(addr++, hours);
    writeRTC(addr++, daydate);
}

// Enable or disable an alarm "interrupt" which asserts the INT pin
// on the RTC.
void Customized_DS3232RTC::alarmInterrupt(byte alarmNumber, bool interruptEnabled) {
    uint8_t controlReg, mask;

    controlReg = readRTC(RTC_CONTROL);
    mask = _BV(A1IE) << (alarmNumber - 1);
    if (interruptEnabled)
        controlReg |= mask;
    else
        controlReg &= ~mask;
    writeRTC(RTC_CONTROL, controlReg);
}

// Returns true or false depending on whether the given alarm has been
// triggered, and resets the alarm flag bit.
bool Customized_DS3232RTC::alarm(byte alarmNumber) {
    uint8_t statusReg, mask;

    statusReg = readRTC(RTC_STATUS);
    mask = _BV(A1F) << (alarmNumber - 1);
    if (statusReg & mask) {
        statusReg &= ~mask;
        writeRTC(RTC_STATUS, statusReg);
        return true;
    } else {
        return false;
    }
}

// Decimal-to-BCD conversion
uint8_t Customized_DS3232RTC::dec2bcd(uint8_t n) { return n + 6 * (n / 10); }

// BCD-to-Decimal conversion
uint8_t Customized_DS3232RTC::bcd2dec(uint8_t n) { return n - 6 * (n >> 4); }

#ifdef ARDUINO_ARCH_AVR
Customized_DS3232RTC RTC;
#endif
